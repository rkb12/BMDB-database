import pymatgen as mg
from pymatgen.io.vasp.outputs import BSVasprun, Vasprun
# from pymatgen import Spin
# from pymatgen.electronic_structure.plotter import BSPlotter, BSDOSPlotter, DOSplotter

import matplotlib.pyplot as plt
plt.switch_backend('agg')

run = BSVasprun("vasprun.xml", parse_projected_eigen=True)

bs = run.get_band_structure("KPOINTS")

# print (bs.get_band_gap())
## link http://pymatgen.org/pymatgen.electronic_structure.bandstructure.html
print (bs.get_band_gap()["energy"])

# print (bs.get_vbm()["kpoint"])
