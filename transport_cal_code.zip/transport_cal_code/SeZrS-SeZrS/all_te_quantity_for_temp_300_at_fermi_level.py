from pymatgen.electronic_structure.boltztrap2 import *
from monty.serialization import loadfn
import os
import numpy as np

#vrun = Vasprun('vasprun.xml',parse_projected_eigen=True)
#data = VasprunBSLoader(vrun)
#bs = vrun.get_band_structure()
#nele = vrun.parameters['NELECT']
#st = vrun.final_structure
#data = VasprunBSLoader(bs,structure=st,nelect=nele)
data = VasprunBSLoader.from_file('vasprun.xml')

bztInterp = BztInterpolator(data,lpfac=10,energy_range=4,curvature=True)

bztTransp = BztTransportProperties(bztInterp,temp_r = np.arange(300,600,300))


# print('\t'.join(['Temp', '\mu', 'rows', 'columns tensor']))
#for p in bztTransp.Conductivity_mu, bztTransp.Seebeck_mu, bztTransp.Kappa_mu, \
#         bztTransp.Effective_mass_mu, bztTransp.Power_Factor_mu, bztTransp.Carrier_conc_mu:
# for p in bztTransp.Seebeck_mu, bztTransp.temp_r, bztTransp.mu_r_eV:
#for p in bztTransp.Seebeck_mu, bztTransp.mu_r_eV:
    #print('\t'.join([str(i) for i in p.shape]))
    #print([i for i in p])
#    print([str(i) for i in p])
# print ([len(i) for i in bztTransp.Seebeck_mu])
# print (len(bztTransp.mu_r_eV))
#print ([str(i) for i in bztTransp.mu_r])

for ctr, i in enumerate(bztTransp.mu_r_eV):
	if np.round(i, 3)==0 or float(bztTransp.mu_r_eV[ctr]) > 0:
		# print (ctr, i)
		n=ctr
		break

mu_=bztTransp.mu_r_eV

## seebeck coefficient
s_=bztTransp.Seebeck_mu
s_vec=[s_[0][n][0][0], s_[0][n][1][1], s_[0][n][2][2]]

# print (s_[0][n])
# print (s_vec, mu_[n])

file=open('seebeck_300_fermi.dat','w+')
file.write(str(s_vec[0]))
file.write('       ')
file.write(str(s_vec[1]))
file.write('       ')
file.write(str(s_vec[2]))
file.close()

### power factor s2sigma
s2sigma=bztTransp.Power_Factor_mu
s2sigma_vec=[s2sigma[0][n][0][0], s2sigma[0][n][1][1], s2sigma[0][n][2][2]]

file1=open('powerfactor_300_fermi.dat','w+')
file1.write(str(s2sigma_vec[0]))
file1.write('       ')
file1.write(str(s2sigma_vec[1]))
file1.write('       ')
file1.write(str(s2sigma_vec[2]))
file1.close()

### conductivity

sigma=bztTransp.Conductivity_mu
sigma_vec=[sigma[0][n][0][0], sigma[0][n][1][1], sigma[0][n][2][2]]

file1=open('sigma_300_fermi.dat','w+')
file1.write(str(sigma_vec[0]))
file1.write('       ')
file1.write(str(sigma_vec[1]))
file1.write('       ')
file1.write(str(sigma_vec[2]))
file1.close()

### effective mass

me=bztTransp.Effective_mass_mu
me_vec=[me[0][n][0][0], me[0][n][1][1], me[0][n][2][2]]

file1=open('meff_300_fermi.dat','w+')
file1.write(str(me_vec[0]))
file1.write('       ')
file1.write(str(me_vec[1]))
file1.write('       ')
file1.write(str(me_vec[2]))
file1.close()
