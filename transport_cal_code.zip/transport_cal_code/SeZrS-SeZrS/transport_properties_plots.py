################### Details  ######################################################################################
############ written by Ranjan Kumar Barik, Department of Physics, University of South Florida, mail: ranjan737@usf.edu, sran9125@gmail.com ##############################################################


from pymatgen.electronic_structure.boltztrap2 import *
from monty.serialization import loadfn
import os
import numpy as np
import sys

data = VasprunBSLoader.from_file('vasprun.xml')

bztInterp = BztInterpolator(data,lpfac=10,energy_range=4,curvature=True)

## for intial calculation please uncomment the below line
#bztTransp = BztTransportProperties(bztInterp,temp_r = np.arange(300,1300,300),doping=10.**np.arange(16,23), save_bztTranspProps=True,fname='bztTranspProps.json.gz')

bztTransp = BztTransportProperties(bztInterp,load_bztTranspProps=True,fname='bztTranspProps.json.gz')


cn1=[]
cn2=[]
cn3=[]
cn4=[]
mu=[]
for i in bztTransp.mu_r_eV:
	mu.append(i)
mu=[float(i) for i in mu]

temp=[300, 600, 900, 1200]
for i1 in bztTransp.Conductivity_mu[0]:
	cn1.append(i1[0][0])
for i2 in bztTransp.Conductivity_mu[1]:
	cn2.append(i2[0][0])
for i3 in bztTransp.Conductivity_mu[2]:
	cn3.append(i3[0][0])
for i4 in bztTransp.Conductivity_mu[3]:
	cn4.append(i4[0][0])

cn1=[float(i)*1e14 for i in cn1]
cn2=[float(i)*1e14 for i in cn2]
cn3=[float(i)*1e14 for i in cn3]
cn4=[float(i)*1e14 for i in cn4]

fig, ax = plt.subplots(1, 1, figsize=(8, 8))

ax.plot(mu, cn1, label='T = 300')
ax.plot(mu, cn2, label='T = 600')
ax.plot(mu, cn3, label='T = 900')
ax.plot(mu, cn4, label='T = 1200')
ax.set_xlim(-1.5, 1.5)

ax.set_xlabel(r'$\mu$ (eV)', fontsize=25)
ax.set_ylabel(r'$\sigma/\tau (S m^{-1} s^{-1}$)', fontsize=25)

ax.legend(fontsize = 15)

ax.tick_params(axis='both', which='major', labelsize=20)

for axis in ['top','bottom','left','right']:
	ax.spines[axis].set_linewidth(2)
	ax.spines[axis].set_color('k')
	ax.set_facecolor(color='None')

t = ax.yaxis.get_offset_text()
t.set_size(20)
plt.tight_layout()
plt.savefig('Sigma_vs_chemical_potential_BMD_SeZrS-SeZrS_31.png')


seeb1=[]
seeb2=[]
seeb3=[]
seeb4=[]

temp=[300, 600, 900, 1200]
for i1 in bztTransp.Seebeck_mu[0]:
	seeb1.append(i1[0][0])
for i2 in bztTransp.Seebeck_mu[1]:
	seeb2.append(i2[0][0])
for i3 in bztTransp.Seebeck_mu[2]:
	seeb3.append(i3[0][0])
for i4 in bztTransp.Seebeck_mu[3]:
	seeb4.append(i4[0][0])

seeb1=[float(i) for i in seeb1]
seeb2=[float(i) for i in seeb2]
seeb3=[float(i) for i in seeb3]
seeb4=[float(i) for i in seeb4]

fig, ax = plt.subplots(1, 1, figsize=(8, 8))

ax.plot(mu, seeb1, label='T = 300')
ax.plot(mu, seeb2, label='T = 600')
ax.plot(mu, seeb3, label='T = 900')
ax.plot(mu, seeb4, label='T = 1200')
ax.set_xlim(-1.5, 1.5)

ax.set_xlabel(r'$\mu$ (eV)', fontsize=25)
ax.set_ylabel(r'S ($\mu V/K$)', fontsize=25)

ax.legend(fontsize = 15)

ax.tick_params(axis='both', which='major', labelsize=20)

for axis in ['top','bottom','left','right']:
	ax.spines[axis].set_linewidth(2)
	ax.spines[axis].set_color('k')
	ax.set_facecolor(color='None')

t = ax.yaxis.get_offset_text()
t.set_size(20)
plt.tight_layout()
plt.savefig('Seebeck_vs_chemical_potential_BMD_SeZrS-SeZrS_31.png')


pf1=[]
pf2=[]
pf3=[]
pf4=[]

temp=[300, 600, 900, 1200]
for i1 in bztTransp.Power_Factor_mu[0]:
	pf1.append(i1[0][0])
for i2 in bztTransp.Power_Factor_mu[1]:
	pf2.append(i2[0][0])
for i3 in bztTransp.Power_Factor_mu[2]:
	pf3.append(i3[0][0])
for i4 in bztTransp.Power_Factor_mu[3]:
	pf4.append(i4[0][0])

pf1=[float(i)*1e11 for i in pf1]
pf2=[float(i)*1e11 for i in pf2]
pf3=[float(i)*1e11 for i in pf3]
pf4=[float(i)*1e11 for i in pf4]  ###unit is in watt/mk2s

fig, ax = plt.subplots(1, 1, figsize=(8, 8))

ax.plot(mu, pf1, label='T = 300')
ax.plot(mu, pf2, label='T = 600')
ax.plot(mu, pf3, label='T = 900')
ax.plot(mu, pf4, label='T = 1200')
ax.set_xlim(-1.5, 1.5)

ax.set_xlabel(r'$\mu$ (eV)', fontsize=25)
ax.set_ylabel(r'S$^{2} \sigma / \tau (W/mK^2s$)', fontsize=25)

ax.legend(fontsize = 15)

ax.tick_params(axis='both', which='major', labelsize=20)

for axis in ['top','bottom','left','right']:
	ax.spines[axis].set_linewidth(2)
	ax.spines[axis].set_color('k')
	ax.set_facecolor(color='None')

t = ax.yaxis.get_offset_text()
t.set_size(20)
plt.tight_layout()
plt.savefig('Power_factor_vs_chemical_potential_BMD_SeZrS-SeZrS_31.png')
