################### Details  ######################################################################################
############ written by Ranjan Kumar Barik, Department of Physics, University of South Florida, mail: ranjan737@usf.edu, sran9125@gmail.com ##############################################################

import numpy as np
import sys
import matplotlib.pyplot as plt


########## reading outcar, kpoints, poscar ########################
with open('OUTCAR','r') as f:
	lines = f.read().split("\n") 
with open('KPOINTS','r') as f:
	klines = f.read().split("\n")
kpoints_bet_each_hsp = int(klines[1])
with open('POSCAR','r') as f:
	poslines = f.read().split("\n") 
tit= poslines[0]
########################## done ###################################




########################## fermi energy, nkpts, nbands, with their line number
hsp = []
fermi = 'E-fermi'
nband = 'NBANDS'
kpoint1 = 'k-point     1'
spin_1='k-point     1'
k_list = 'k-points in reciprocal lattice and weights'
nkpts = 'NKPTS'
for i,line in enumerate(lines):
	if fermi in line: 
		fermi_line_no = int("{}".format(i))  # E-fermi line no
	if nband in line:
		nband_line_no = int("{}".format(i)) # NBANDS line no
	if kpoint1 in line:
		kpoint1_line_no= int("{}".format(i)) # first k-point line no
	if k_list in line:
		k_reci_line_no= int("{}".format(i)) # first k-point line no
	if nkpts in line:
		nkpts_line_no= int("{}".format(i)) # first k-point line no
	if spin_1 in line:
		spin_1_line_no= int("{}".format(i)) # first k-point line no


store_line = []
out = open("OUTCAR", "r")
store_line = out.readlines()
line1 = store_line[fermi_line_no]
line2 = store_line[nband_line_no]
line3 = store_line[nkpts_line_no]
E_fermi = float(line1.split()[2])
nbands = int(line2.split()[14])
nkpts_value = int(line3.split()[3])
out.close()
for i,line in enumerate(lines):
	spin_21='k-point   '
	spin_2=spin_21+str(nkpts_value)
	if spin_2 in line:
		spin_21_line_no= int("{}".format(i))
		spin_2_line_no=spin_21_line_no + nbands + 1
		
################################### done ###########################################

############################### kpoints for band structure #########################
# please edit this section if you have used different kpoints file

kx = []
ky = []
kz = []
klines = []
for i in range(k_reci_line_no + 1, k_reci_line_no + 241):
	klines.append(list(lines[i].split()))
#print (klines[1][1])
for i in range(len(klines)):
	kx.append(float(klines[i][0]))	
	ky.append(float(klines[i][1]))	
	kz.append(float(klines[i][2]))


kxx = []
kyy = []
kzz = []
klines1 = []
for j in range(k_reci_line_no + 241, k_reci_line_no + nkpts_value + 1):
	klines1.append(list(lines[j].split()))
for i in range(len(klines1)):
	kxx.append(float(klines1[i][0]))	
	kyy.append(float(klines1[i][1]))	
	kzz.append(float(klines1[i][2]))	

	
#print (kx, ky, kz)
dist = 0
kx1 = 0
ky1 = 0
kz1 = 0
kpoints = []
dist0= np.sqrt((kx[0]-kx1)**2 + (ky[0]-ky1)**2 + (kz[0]-kz1)**2)
for i in range(len(kx)):
	dist= dist + np.sqrt((kx[i]-kx1)**2 + (ky[i]-ky1)**2 + (kz[i]-kz1)**2)
	kx1 = kx[i]
	ky1 = ky[i]
	kz1 = kz[i]
	kpoints.append(dist-dist0)
d_last=dist-dist0
dist1 = 0
kx2 = kx[-1]
ky2 = ky[-1]
kz2 = kz[-1]
# kpoints = []
dist00= np.sqrt((kxx[0]-kx2)**2 + (kyy[0]-ky2)**2 + (kzz[0]-kz2)**2)
for i in range(len(kxx)):
        dist1= dist1 + np.sqrt((kxx[i]-kx2)**2 + (kyy[i]-ky2)**2 + (kzz[i]-kz2)**2)
        kx2 = kxx[i]
        ky2 = kyy[i]
        kz2 = kzz[i]
        kpoints.append(d_last + dist1 - dist00)
############################# done ############################################


############################### extraction of band energies #######################
spin_1_lines=[]

for i in range(spin_1_line_no, spin_2_line_no+1):
	spin_1_lines.append(lines[i].split())

spin_1_bands=[]

for i in range(2, len(spin_1_lines), nbands + 3):
	test=[]
	for j in range(i, i + nbands):
		test.append(spin_1_lines[j])
	spin_1_bands.append(test)
spin_1_band_energies = []

for i, lines1 in enumerate(spin_1_bands):
	test = []
	for line1 in lines1:
		test.append(float(line1[1]))
	spin_1_band_energies.append(test)

spin_1_band_energies1 = np.transpose(spin_1_band_energies)



################################### done ####################################


############### ploting of dft band ####################
spin_1_band_energies1 = [[float(i) - E_fermi for i in line] for line in spin_1_band_energies1]
fig, ax = plt.subplots(1, 1, figsize=(10, 8))
for i in range(len(spin_1_band_energies1)):
	ax.plot(kpoints[0 : 240],spin_1_band_energies1[i][0 : 240], 'b')
	ax.plot(kpoints[240 : -1],spin_1_band_energies1[i][240 : -1], 'b')
x_coordinates = [kpoints[0], kpoints[-1]]
y_coordinates = [0, 0]
ax.plot(x_coordinates,y_coordinates, 'r--')
ax.set_xlim(kpoints[0], kpoints[-1])
ax.set_ylim(-2, 2)

ax.set_ylabel(r'Energy (eV)', fontsize=25)

ax.set_xticks([kpoints[0], kpoints[80], kpoints[160], kpoints[240], kpoints[320], kpoints[-1]])
ax.set_xticklabels(['M', '$\Gamma$', 'K', 'M|K$^{\prime}$', '$\Gamma$', 'K'])
ax.tick_params(axis='both', which='major', labelsize=20)

ax = plt.gca()
ax.grid(which='major', axis='x', linestyle='--')

for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(2)
        ax.spines[axis].set_color('k')
        ax.set_facecolor(color='None')

# t = ax.yaxis.get_offset_text()
# t.set_size(20)
fig.tight_layout()
plt.savefig('band_soc_bilayer.png')
################### done ploting ########################
