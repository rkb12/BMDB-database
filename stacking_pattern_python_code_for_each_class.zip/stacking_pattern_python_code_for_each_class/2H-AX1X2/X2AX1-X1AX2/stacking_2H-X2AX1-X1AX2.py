################### Details  ######################################################################################
############ written by Ranjan Kumar Barik, Department of Physics, University of South Florida, mail: ranjan737@usf.edu, sran9125@gmail.com ##############################################################


import numpy as np
import spglib
import sys
from numpy.linalg import inv
import os
import shutil


def pos_final(pos_7th, positions):
    
    poscar_final=[i for i in pos_7th]
    for j in positions:
        poscar_final.append(j)
        
    return poscar_final
        

def pde(a1, a2, lp):
    x=a1 + (a2*lp)
    if x>=lp:
        x=x - lp
    return x

rootdir=os.getcwd()

f=open('POSCAR_relax_MoSTe_4002.vasp','r')

lines=f.readlines()
con=[]
n=0
for line in lines:
	con.append(line.split())	
for i in range(len(con[6])):
	n=n+int(con[6][i])
    
lp=float(con[2][0])
positions=[]
for j in range(8,n+8):
	fl_l=[float(item) for item in con[j]]
	positions.append(fl_l)


lattice = np.array([[float(con[2][0]), float(con[2][1]), float(con[2][2])],
                    [float(con[3][0]), float(con[3][1]), float(con[3][2])],
                    [float(con[4][0]), float(con[4][1]), float(con[4][2])]]) * float(con[1][0])

z=np.asarray(positions)
y=np.matmul(z, lattice)

pos_mono = np.round(y, decimals=9)
    
pos_bi=[]
for k in pos_mono:
    pos_bi.append(k)

z_cord= [pos_mono[0][2], pos_mono[1][2], pos_mono[2][2]]



z_extension=(max(z_cord)-min(z_cord)) + 3.3

d1=abs(pos_mono[0][2]-pos_mono[1][2])
d2=abs(pos_mono[0][2]-pos_mono[2][2])

diff=abs(d1-d2)
pos_bi.append([pos_mono[0][0], pos_mono[0][1], pos_mono[0][2]-z_extension-diff])


if pos_mono[1][2] > pos_mono[2][2]:
    pos_bi.append([pos_mono[1][0], pos_mono[1][1], pos_mono[0][2]-z_extension-d1-diff])
    pos_bi.append([pos_mono[2][0], pos_mono[2][1], pos_mono[0][2]-z_extension+d2-diff])

if pos_mono[1][2] < pos_mono[2][2]:
    pos_bi.append([pos_mono[1][0], pos_mono[1][1], pos_mono[0][2]-z_extension + d1-diff])
    pos_bi.append([pos_mono[2][0], pos_mono[2][1], pos_mono[0][2]-z_extension - d2-diff])




pos_bi=[[k1[0], k1[1], k1[2] + z_extension + diff] for k1 in pos_bi]
    
pos_bi = np.round(pos_bi, decimals=9)

pos_bi_final_AA=[pos_bi[0], pos_bi[3], pos_bi[1], pos_bi[4], pos_bi[2], pos_bi[5]]

pos_bi_final_AB=[pos_bi[0], [pos_bi[1][0], pos_bi[1][1], pos_bi[3][2]], pos_bi[1], [pos_bi[0][0], pos_bi[0][1], pos_bi[4][2]], pos_bi[2], [pos_bi[0][0], pos_bi[0][1], pos_bi[5][2]]]

pos_bi_final_AA1=[pos_bi[0], [pos_bi[3][0], (2/3)*float(con[3][1]), pos_bi[3][2]], pos_bi[1], [pos_bi[4][0]- abs(float(con[3][0])), pos_bi[4][1]-(1/3*float(con[3][1])), pos_bi[4][2]], pos_bi[2], [pos_bi[5][0] - abs(float(con[3][0])), pos_bi[5][1]-(1/3*float(con[3][1])), pos_bi[5][2]]]

pos_bi_final_AA2=[pos_bi[0], [float(con[2][0])/2, (1/3)*float(con[3][1]), pos_bi[3][2]], pos_bi[1], [pos_bi[4][0]- abs(float(con[3][0])), (2/3)*float(con[3][1]), pos_bi[4][2]], pos_bi[2], [pos_bi[5][0]- abs(float(con[3][0])), (2/3)*float(con[3][1]), pos_bi[5][2]]]

pos_bi_final_AB1=[pos_bi[0], [pos_bi[0][0], pos_bi[0][1], pos_bi[3][2]], pos_bi[1], [pos_bi[4][0] - abs(float(con[3][0])), (2/3)*float(con[3][1]), pos_bi[4][2]], pos_bi[2], [pos_bi[5][0] - abs(float(con[3][0])), (2/3)*float(con[3][1]), pos_bi[5][2]]]

pos_bi_final_AB2=[pos_bi[0], [pos_bi[0][0], (2/3)*float(con[3][1]), pos_bi[3][2]], pos_bi[1], [abs(float(con[3][0])), (1/3)*float(con[3][1]), pos_bi[4][2]], pos_bi[2],[abs(float(con[3][0])), (1/3)*float(con[3][1]), pos_bi[5][2]]]

lattice_new1= np.array([[float(con[2][0]), float(con[2][1]), float(con[2][2])],
                    [float(con[3][0]), float(con[3][1]), float(con[3][2])],
                    [float(con[4][0]), float(con[4][1]), float(con[4][2]) + z_extension]]) * float(con[1][0])


lattice_new= np.round(lattice_new1, decimals=12)   
x1=inv(lattice_new)    

pos_bi_final_AA_dir=np.round(np.matmul(pos_bi_final_AA, x1), decimals=9)

pos_bi_final_AA1_dir=np.round(np.matmul(pos_bi_final_AA1, x1), decimals=9)

pos_bi_final_AA2_dir=np.round(np.matmul(pos_bi_final_AA2, x1), decimals=9)

pos_bi_final_AB_dir=np.round(np.matmul(pos_bi_final_AB, x1), decimals=9)

pos_bi_final_AB1_dir=np.round(np.matmul(pos_bi_final_AB1, x1), decimals=9)

pos_bi_final_AB2_dir=np.round(np.matmul(pos_bi_final_AB2, x1), decimals=9)


atom_num=[2, 2, 2]
pos_new=[con[0], con[1], lattice_new[0], lattice_new[1], lattice_new[2], con[5], atom_num, ['Direct'] ]

POSCAR_AA=pos_final(pos_new,pos_bi_final_AA_dir)
POSCAR_AA1=pos_final(pos_new,pos_bi_final_AA1_dir)
POSCAR_AA2=pos_final(pos_new,pos_bi_final_AA2_dir)
POSCAR_AB=pos_final(pos_new,pos_bi_final_AB_dir)
POSCAR_AB1=pos_final(pos_new,pos_bi_final_AB1_dir)
POSCAR_AB2=pos_final(pos_new,pos_bi_final_AB2_dir)

POSCAR_list=[POSCAR_AA, POSCAR_AA1, POSCAR_AA2, POSCAR_AB, POSCAR_AB1, POSCAR_AB2]

stacking_list=['AA', 'AA1', 'AA2', 'AB', 'AB1', 'AB2']

for ctr, stack in enumerate(stacking_list):
    os.mkdir(stack)
    os.chdir(stack)
    f = open('POSCAR', 'w+')
    for line in POSCAR_list[ctr]:
        for j in range(len(line)):
            f.write(str(line[j]))
            f.write("  ")
        f.write("\n")
    f.close()
    os.chdir(rootdir)
